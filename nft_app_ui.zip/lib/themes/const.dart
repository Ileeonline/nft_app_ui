import 'package:flutter/material.dart';

var backgroundColor = Colors.grey[300];
var tabTextStyle = TextStyle(color: Colors.grey[600]);